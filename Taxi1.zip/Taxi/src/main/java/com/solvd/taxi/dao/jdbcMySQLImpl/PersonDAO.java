package com.solvd.taxi.dao.jdbcMySQLImpl;

import com.solvd.taxi.dao.IPersonDAO;
import com.solvd.taxi.models.PersonModel;

public class PersonDAO implements IPersonDAO {
    @Override
    public void createPerson(PersonModel person) {
        
    }

    @Override
    public void updatePersonById(int id) {

    }

    @Override
    public void deletePersonById(int id) {

    }

    @Override
    public PersonModel getPersonById(int id) {
        return null;
    }
}
