package com.solvd.taxi.models;

public class AddressesModel {
}
