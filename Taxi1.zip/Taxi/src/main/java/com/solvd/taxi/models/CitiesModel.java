package com.solvd.taxi.models;

public class CitiesModel {
}
